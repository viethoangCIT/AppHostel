package com.example.viethoang.apphostelgooglemaps;

public class Place {
    private String id_place;
    private String lnglat;
    private String giaPhong;
    private String dienTich;
    private String dienThoai;
    private String info;
    private String title;

    public Place() {
    }

    public Place(String id_place, String lnglat, String giaPhong, String dienTich, String dienThoai, String info, String title) {
        this.id_place = id_place;
        this.lnglat = lnglat;
        this.giaPhong = giaPhong;
        this.dienTich = dienTich;
        this.dienThoai = dienThoai;
        this.info = info;
        this.title = title;
    }

    public String getId_place() {
        return id_place;
    }

    public void setId_place(String id_place) {
        this.id_place = id_place;
    }

    public String getLnglat() {
        return lnglat;
    }

    public void setLnglat(String lnglat) {
        this.lnglat = lnglat;
    }

    public String getGiaPhong() {
        return giaPhong;
    }

    public void setGiaPhong(String giaPhong) {
        this.giaPhong = giaPhong;
    }

    public String getDienTich() {
        return dienTich;
    }

    public void setDienTich(String dienTich) {
        this.dienTich = dienTich;
    }

    public String getDienThoai() {
        return dienThoai;
    }

    public void setDienThoai(String dienThoai) {
        this.dienThoai = dienThoai;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
